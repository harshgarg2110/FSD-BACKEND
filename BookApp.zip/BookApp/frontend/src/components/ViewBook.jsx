import React from "react";

const ViewBook = () => {
  return (
    <div>
      <h1>ViewBook</h1>
    </div>
  );
};

export default ViewBook;
