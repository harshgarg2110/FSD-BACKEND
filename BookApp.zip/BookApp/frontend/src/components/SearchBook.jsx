import React from "react";

const SearchBook = () => {
  return (
    <div>
      <h1>SearchBook</h1>
    </div>
  );
};

export default SearchBook;
