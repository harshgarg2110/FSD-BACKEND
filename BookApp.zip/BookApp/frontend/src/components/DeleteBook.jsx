import React from "react";

const DeleteBook = () => {
  return (
    <div>
      <h1>DeleteBook</h1>
    </div>
  );
};

export default DeleteBook;
