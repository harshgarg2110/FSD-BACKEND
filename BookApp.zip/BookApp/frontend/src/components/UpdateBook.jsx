import React from "react";

const UpdateBook = () => {
  return (
    <div>
      <h1>UpdateBook</h1>
    </div>
  );
};

export default UpdateBook;
