import React from "react";

const AddBook = () => {

    const handlebook=async (e) => {
    e.preventDefault();
    const title = e.target.title        
    }
  return (
    <div>
      <h1>AddBook</h1>
    </div>
  );
};

export default AddBook;
